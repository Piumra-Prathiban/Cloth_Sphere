package com.clothsphere.service.buyerPortal;

import com.clothsphere.model.buyerPortal.Order;
import com.clothsphere.model.buyerPortal.Buyer;
import com.clothsphere.repository.buyerPortal.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order placeOrder(Order order) {
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("Pending");
        return orderRepository.save(order);
    }

    public List<Order> getOrdersByBuyer(Buyer buyer) {
        return orderRepository.findByBuyer(buyer);
    }
}

